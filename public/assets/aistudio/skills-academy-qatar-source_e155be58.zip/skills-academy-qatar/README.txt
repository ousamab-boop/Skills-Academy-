Skills Academy Qatar — website source export

This archive contains the replacement website's source code, styles, configuration,
static assets, and page content. The course and contact copy is in src/App.tsx;
the hero image and favicon are in public/.

No database is configured for this site, so there is no separate database export.
The WhatsApp inquiry links are part of the site source.

To run it in the original Replit workspace, extract this folder back to:
  artifacts/skills-academy-site

Then run these commands from the workspace root:
  pnpm install
  pnpm --filter @workspace/skills-academy-site run dev

Dependencies are not bundled. They are managed by the original workspace's
pnpm configuration. This export excludes installed dependencies and generated
build/cache files.
